#!/usr/bin/env python
#encoding=utf-8

# __author__ fanyingjie
# __time__ 2018-6-27

import subprocess
import ast


def unzip():
	subprocess.getoutput("tar  -xvf jixianjiancha.tar.gz")

def scanResult():
	f=open("script.txt",'r')
	scripts=[]
	for line in f.readlines():
		scripts.append(line.strip("\n").strip())
	f.close()
	result=[]

	#execut script
	for script in scripts:
		commandsResult=subprocess.getoutput("python jixianjiancha/%s"%(script))
		print("[+] %s execut success"%(script))
		result.append({"exploit":ast.literal_eval(commandsResult.replace("u'","'"))})
	return result

def show(result):
	subprocess.getoutput("cp templates/test.html templates/result.html")
	f1=open("templates/test.html","r+")
	f2=open("templates/result.html","w+")
	for line in f1.readlines():
		f2.write(line.replace("%test%",'"'+str(result)+'"'))
	f1.close()
	f2.close()

unzip()
result=scanResult()
show(result)
subprocess.getoutput("tar vcf templates.tar.gz templates/")
print("[*] 检查完成 请将templates.tar.gz 保存本地,查看其中的result.html")