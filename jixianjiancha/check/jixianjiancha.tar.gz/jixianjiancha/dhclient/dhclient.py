#!/usr/bin/env python
#encoding=utf-8

# __author__ fanyingjie
# __time__ 2018-07-02

import commands
import sys
import re

reload(sys)
sys.setdefaultencoding('utf-8')


		
class  dhclientPoc(object):
	"""docstring for  portScanner"""
	vulID = '0'  # ssvid ID 如果是提交漏洞的同时提交 PoC,则写成 0
	version = '1' #默认为1
	vulDate = '2018-07-02' #漏洞公开的时间,不知道就写今天

	author = 'fanyingjie' #  PoC作者的大名
	createDate = '2018-07-02'# 编写 PoC 的日期
	updateDate = '2018-07-02'# PoC 更新的时间,默认和编写时间一样
	references = ["https://blog.csdn.net/liu2612348/article/details/80388943"]# 漏洞地址来源,0day不用写
	name = 'dhclient and dnsmasq'# PoC 名称
	appPowerLink = ''# 漏洞厂商主页地址
	appName = 'dhclient and dnsmasq'# 漏洞应用名称
	appVersion = ' '# 漏洞影响版本
	vulType = '客户端代码执行'#漏洞类型,类型参考见 漏洞类型规范表
	desc = '''
		恶意的 DHCP 服务器或者本地网络上的攻击者，可通过欺骗现有的 DHCP 响应的方式利用此漏洞，
		对使用 NetworkManager 的 DHCP 客户端获取相应的请求时，获得 root 权限，可以执行系统所有的命令。
	''' # 漏洞简要描述
	samples = []# 测试样列,就是用 PoC 测试成功的网站
	install_requires = [] # PoC 第三方模块依赖，请尽量不要使用第三方模块，必要时请参考《PoC第三方模块依赖说明》填写



	#验证漏洞
	def verify(self):
		payload="rpm -qa --changelog dhclient  | grep CVE-2018"
		tag=0
		try:
			result={u"DHCP客户端命令执行漏洞":{}}
			commandResult=commands.getoutput(payload)
			if("CVE-2018-1111" not in commandResult):
				tag += 1 
				result[u"DHCP客户端命令执行漏洞"][u"dhclient漏洞"]={"describe":u"服务器存在DHCP客户端命令执行漏洞","tag":1,"level":u"严重","repair":u"升级dnclient,命令 yum update dhclient"}
			payload="rpm -q --changelog dnsmasq |grep CVE-2017-14491"	
			commandResult=commands.getoutput(payload)
			if("CVE-2017-14491" not in commandResult):
				tag += 1
				result[u"DHCP客户端命令执行漏洞"][u"dnsmasq 堆溢出漏洞"]={"describe":u"服务器存在dnsmasq 堆溢出漏洞","tag":1,"level":u"严重","repair":u"升级dnsmasq,命令 yum update dnsmasq"}
			result['rows']=tag
			if(tag == 0):
				return {u"DHCP客户端命令执行漏洞":{"":{"describe":u"本服务器没有安装DHCP客户端命令执行漏洞","tag":0,"level":u"严重","repair":u"暂无"}},"rows":1} 
			return result
		except Exception as e:
			return {u"DHCP客户端命令执行漏洞":{"":{"describe":u"检测DHCP客户端命令执行漏洞失败","tag":1,"level":u"严重","repair":u"请联系网络安全部，手工检测"}},"rows":1}
		



a=dhclientPoc()
print a.verify()
