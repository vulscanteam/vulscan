#!/usr/bin/env python
#encoding=utf-8

# __author__ test
# __time__ 2018-4-25

import commands
import sys
import re

reload(sys)
sys.setdefaultencoding('utf-8')


		
class  sshPoc(object):
	"""docstring for  portScanner"""
	vulID = '0'  # ssvid ID 如果是提交漏洞的同时提交 PoC,则写成 0
	version = '1' #默认为1
	vulDate = '2018-04-28' #漏洞公开的时间,不知道就写今天

	author = 'test' #  PoC作者的大名
	createDate = '2018-04-28'# 编写 PoC 的日期
	updateDate = '2018-04-28'# PoC 更新的时间,默认和编写时间一样
	references = []# 漏洞地址来源,0day不用写
	name = 'sshPoc'# PoC 名称
	appPowerLink = ''# 漏洞厂商主页地址
	appName = 'ssh 基本信息检查'# 漏洞应用名称
	appVersion = ''# 漏洞影响版本
	vulType = ''#漏洞类型,类型参考见 漏洞类型规范表
	desc = '''
		检查ssh是否允许root登录，是否允许空密码登录，是否允许密钥登陆，是否允许密码登录
	''' # 漏洞简要描述
	samples = []# 测试样列,就是用 PoC 测试成功的网站
	install_requires = [] # PoC 第三方模块依赖，请尽量不要使用第三方模块，必要时请参考《PoC第三方模块依赖说明》填写



	#验证漏洞
	def verify(self):
		payload='''cat /etc/ssh/sshd_config'''
		result={u"ssh配置":{}}
		try:
			commandResult=commands.getoutput(payload) #读取ssh配置文件
			if ("Permission denied" in commandResult):
				return {u"ssh配置":{"":{"describe":u"权限不足,请使用root帐号","tag":1,"level":u"高危","repair":u"请使用root帐号进行主机检查"}},"rows":1}
			paPattern="\\n\s{0,6}PasswordAuthentication\s{1,5}([yesnoYESNO]{1,10})\\n" #是否允许密码登录的正则表达式
			prPattern="\\n\s{0,6}PermitRootLogin\s{1,5}([yesnoYESNO]{1,10})\\n" #是否允许root登录的正则表达式	
			raPattern="\\n\s{0,6}RSAAuthentication\s{1,5}([yesnoYESNO]{1,10})\\n" #是否允许密钥登录的正则表达式
			pkPattern="\\n\s{0,6}PubkeyAuthentication\s{1,5}([yesnoYESNO]{1,10})\\n" #是否允许密钥登录的正则表达式
			pePattern="\\n\s{0,6}PermitEmptyPasswords\s{1,5}([yesnoYESNO]{1,10})\\n" #是否允许空密码登录的正则表达式


			paresult=re.findall(paPattern,commandResult)
			if(len(paresult)!=0):
				paresult=paresult[0]
			else:
				paresult="no"
			prresult=re.findall(prPattern,commandResult)
			if(len(prresult)!=0):
				prresult=prresult[0]
			else:
				prresult="yes"
			raresult=re.findall(raPattern,commandResult)
			if(len(raresult)!=0):
				raresult=raresult[0]
			else:
				raresult="no"
			pkresult=re.findall(pkPattern,commandResult)
			if(len(pkresult)!=0):
				pkresult=pkresult[0]
			else:
				pkresult="no"
			peresult=re.findall(pePattern,commandResult)
			if(len(peresult)!=0):
				peresult=peresult[0]
			else:
				peresult="no"
			result1=u"允许密码登录:"+paresult+u"\n允许root登录:"+prresult+u"\n允许密钥登录:"+\
			raresult+pkresult+u"\n允许空密码登录"+peresult

			result[u"ssh配置"][u"允许密码登录:"]={}
			result[u"ssh配置"][u"允许密码登录:"]["describe"]=paresult
			if(paresult=="yes"):
				result[u"ssh配置"][u"允许密码登录:"]["tag"]=1
			else:
				result[u"ssh配置"][u"允许密码登录:"]["tag"]=0
			result[u"ssh配置"][u"允许密码登录:"]["level"]=u"中危"
			result[u"ssh配置"][u"允许密码登录:"]["repair"]=u"主机检查完成后建议使用密钥登录"


			result[u"ssh配置"][u"允许root登录:"]={}
			result[u"ssh配置"][u"允许root登录:"]["describe"]=prresult
			if(prresult=="yes"):
				result[u"ssh配置"][u"允许root登录:"]["tag"]=1
			else:
				result[u"ssh配置"][u"允许root登录:"]["tag"]=0
			result[u"ssh配置"][u"允许root登录:"]["level"]=u"中危"
			result[u"ssh配置"][u"允许root登录:"]["repair"]=u"主机检查完成后建议禁止root远程登录"

			result[u"ssh配置"][u"允许密钥登录:"]={}
			result[u"ssh配置"][u"允许密钥登录:"]["describe"]=raresult
			if(raresult=="yes"):
				result[u"ssh配置"][u"允许密钥登录:"]["tag"]=0
			else:
				result[u"ssh配置"][u"允许密钥登录:"]["tag"]=1
			result[u"ssh配置"][u"允许密钥登录:"]["level"]=u"中危"
			result[u"ssh配置"][u"允许密钥登录:"]["repair"]=u"主机检查完成后建议禁止ssh密码登录，只允许密钥登录"

			result[u"ssh配置"][u"允许空密码登录:"]={}
			result[u"ssh配置"][u"允许空密码登录:"]["describe"]=peresult
			if(peresult=="yes"):
				result[u"ssh配置"][u"允许空密码登录:"]["tag"]=1
			else:
				result[u"ssh配置"][u"允许空密码登录:"]["tag"]=0
			result[u"ssh配置"][u"允许空密码登录:"]["level"]=u"中危"
			result[u"ssh配置"][u"允许空密码登录:"]["repair"]=u"禁止空密码登录"
			if(peresult=="yes"):
				result[u"ssh配置"][u"允许空密码登录:"]["tag"]=1


			#test={u"允许密码登录":paresult,u"允许root登录":prresult,u"允许密钥登录":raresult,u"允许空密码登录":peresult}
			result[u"rows"]=4
			return result
		except Exception as e:
			print e
			return {u"ssh配置":{"":{"describe":u"ssh配置读取失败，请重新检查","tag":1,"level":u"高危","repair":u"请重新检查ssh配置文件sshd_config(联系网络安全部)"}},"rows":1}
		

a=sshPoc()
print a.verify()
