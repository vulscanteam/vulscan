#!/usr/bin/env python
#encoding=utf-8

# __author__ fanyingjie
# __time__ 2018-7-5

import commands
import sys


reload(sys)
sys.setdefaultencoding('utf-8')


		
class  ghostScriptPoc(object):
	"""docstring for  portScanner"""
	vulID = '1'  # ssvid ID 如果是提交漏洞的同时提交 PoC,则写成 0
	version = '1' #默认为1
	vulDate = '2018-08-22' #漏洞公开的时间,不知道就写今天

	author = 'fanyingjie' #  PoC作者的大名
	createDate = '2018-08-22'# 编写 PoC 的日期
	updateDate = '2018-08-22'# PoC 更新的时间,默认和编写时间一样
	references = ["http://seclists.org/oss-sec/2018/q3/142"]# 漏洞地址来源,0day不用写
	name = 'iamgemagick'# PoC 名称
	appPowerLink = ''# 漏洞厂商主页地址
	appName = 'iamgeMagick'# 漏洞应用名称
	appVersion = '6.4.0'# 漏洞影响版本
	vulType = 'command injection'#漏洞类型,类型参考见 漏洞类型规范表
	desc = '''
		GhostScript 被许多图片处理库所使用，如 ImageMagick、Python PIL 等，默认情况下这些库会根据图片的内容将其分发给不同的处理方法，其中就包括 GhostScript。
	''' # 漏洞简要描述
	samples = []# 测试样列,就是用 PoC 测试成功的网站
	install_requires = [] # PoC 第三方模块依赖，请尽量不要使用第三方模块，必要时请参考《PoC第三方模块依赖说明》填写



	#验证漏洞
	def verify(self):
		payload="convert jixianjiancha/ghostScript/ghostScript_poc.txt imagemagick_poc.jpg"
		try:
			commandResult=commands.getoutput(payload)
			if ("uid=" in commandResult):
				return {u"GhostScript iamgeMagick漏洞":{"":{"describe":u"服务器存在GhostScript iamgeMagick漏洞","tag":1,"level":u"严重","repair":u"在policy配置文件中添加： policy domain=coder rights=none pattern=PS,EPS,PDF,XPS"}},"rows":1}
			else:
				return {u"GhostScript iamgeMagick漏洞":{"":{"describe":u"服务器不存在GhostScript iamgeMagick漏洞","tag":0,"level":u"严重","repair":u"在policy配置文件中添加： policy domain=coder rights=none pattern=PS,EPS,PDF,XPS"}},"rows":1}
		except Exception as e:
			return {u"GhostScript iamgeMagick漏洞":{"":{"describe":u"服务器不存在GhostScript iamgeMagick漏洞","tag":0,"level":u"严重","repair":u"在policy配置文件中添加： policy domain=coder rights=none pattern=PS,EPS,PDF,XPS"}},"rows":1}
		

a=ghostScriptPoc()
print a.verify()
