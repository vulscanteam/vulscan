#!/usr/bin/env python
#encoding=utf-8

# __author__ test
# __time__ 2018-5-4

import subprocess
import sys



		
class  databasePoc(object):
	"""docstring for  portScanner"""
	vulID = '0'  # ssvid ID 如果是提交漏洞的同时提交 PoC,则写成 0
	version = '1' #默认为1
	vulDate = '2018-05-07' #漏洞公开的时间,不知道就写今天

	author = 'test' #  PoC作者的大名
	createDate = '2018-05-07'# 编写 PoC 的日期
	updateDate = '2018-05-07'# PoC 更新的时间,默认和编写时间一样
	references = []# 漏洞地址来源,0day不用写
	name = 'databasePoc'# PoC 名称
	appPowerLink = ''# 漏洞厂商主页地址
	appName = ''# 漏洞应用名称
	appVersion = ''# 漏洞影响版本
	vulType = ''#漏洞类型,类型参考见 漏洞类型规范表
	desc = '''
		查看数据库的当前允许用户
		1. mysql   		ps -ef |grep mysql|grep -v grep|awk '{print $1}'
		2. postgresql   ps -ef |grep postgres|grep -v grep|awk '{print $1}'
		3. oracle  		ps -ef |grep oracle|grep -v grep|awk '{print $1}'
		4. mongodb		ps -ef |grep mongod|grep -v grep|awk '{print $1}'
	''' # 漏洞简要描述
	samples = []# 测试样列,就是用 PoC 测试成功的网站
	install_requires = [] # PoC 第三方模块依赖，请尽量不要使用第三方模块，必要时请参考《PoC第三方模块依赖说明》填写



	#验证漏洞
	def verify(self):
		
		try:
			mysqlPayload="ps -ef |grep mysql|grep -v grep|awk '{print $1}'"
			commandResult=subprocess.getoutput(mysqlPayload)
			datasplit=list(set(commandResult.split("\n")))
			
			#保存结果
			result={u"数据库运行权限":{}}
			#mysql
			if(datasplit[0]!=""):
				result[u"数据库运行权限"]["mysql"]={}
				if(len(datasplit)==1):
					result[u"数据库运行权限"]["mysql"]["describe"]=datasplit[0].split()[0]
					if(datasplit[0].split()[0]=="root"):
						result[u"数据库运行权限"]["mysql"]["tag"]=1
					else:
						result[u"数据库运行权限"]["mysql"]["tag"]=0
				else:
					for i in range(len(datasplit)):
						if(datasplit[i].split()[0]!="root"):
							result[u"数据库运行权限"]["mysql"]["describe"]=datasplit[i].split()[0]
							if(datasplit[i].split()[0]=="root"):
								result[u"数据库运行权限"]["mysql"]["tag"]=1
							else:
								result[u"数据库运行权限"]["mysql"]["tag"]=0
				result[u"数据库运行权限"]["mysql"]["level"]=u"高危"
				result[u"数据库运行权限"]["mysql"]["repair"]=u"禁止使用root权限启动mysql"

			


			#postgresql
			postgresqlPayload1="ps -ef |grep postgres|grep -v grep|awk '{print $1}'"
			commandResult1=subprocess.getoutput(postgresqlPayload1)
			datasplit1=list(set(commandResult1.split("\n")))
			if(datasplit1[0]!=""):
				result[u"数据库运行权限"][u"postgresql"]={}
				if(len(datasplit1)==1):
					result[u"数据库运行权限"][u"postgresql"]["describe"]=datasplit1[0].split()[0]
					if(datasplit1[0].split()[0]=="root"):
						result[u"数据库运行权限"]["postgresql"]["tag"]=1
					else:
						result[u"数据库运行权限"]["postgresql"]["tag"]=0
				else:
					for i in range(len(datasplit1)):
						if(datasplit1[i].split()[0]!="root"):
							result[u"数据库运行权限"][u"postgresql"]["describe"]=datasplit1[i].split()[0]
							if(datasplit1[i].split()[0]=="root"):
								result[u"数据库运行权限"]["postgresql"]["tag"]=1
							else:
								result[u"数据库运行权限"]["postgresql"]["tag"]=0
				result[u"数据库运行权限"]["postgresql"]["level"]=u"高危"
				result[u"数据库运行权限"]["postgresql"]["repair"]=u"禁止使用root权限启动postgresql"



			#oracle 
			tomcatPayload="ps -ef |grep oracle|grep -v grep|awk '{print $1}'"
			commandResult=subprocess.getoutput(tomcatPayload)
			datasplit=list(set(commandResult.split("\n")))
			if(datasplit[0]!=""):
				result[u"数据库运行权限"][u"oracle"]={}
				if(len(datasplit)==1 ):
					result[u"数据库运行权限"][u"oracle"]["describe"]=datasplit[0].split()[0]
					if(datasplit[0].split()[0]=="root"):
						result[u"数据库运行权限"]["oracle"]["tag"]=1
					else:
						result[u"数据库运行权限"]["oracle"]["tag"]=0
				else:
					for i in range(len(datasplit)):
						if(datasplit[i].split()[0]!="root"):
							result[u"数据库运行权限"][u"oracle"]["describe"]=datasplit[i].split()[0]
							if(datasplit[i].split()[0]=="root"):
								result[u"数据库运行权限"]["oracle"]["tag"]=1
							else:
								result[u"数据库运行权限"]["oracle"]["tag"]=0
				result[u"数据库运行权限"]["oracle"]["level"]=u"高危"
				result[u"数据库运行权限"]["oracle"]["repair"]=u"禁止使用root权限启动oracle"
			


			#mongodb 
			mongodbPayload="ps -ef |grep mongod|grep -v grep|awk '{print $1}'"
			commandResult=subprocess.getoutput(mongodbPayload)
			datasplit=list(set(commandResult.split("\n")))
			if(datasplit[0]!=""):
				result[u"数据库运行权限"][u"mongodb"]={}
				if(len(datasplit)==1 ):
					result[u"数据库运行权限"][u"mongodb"]["describe"]=datasplit[0].split()[0]
					if(datasplit[0].split()[0]=="root"):
						result[u"数据库运行权限"]["mongodb"]["tag"]=1
					else:
						result[u"数据库运行权限"]["mongodb"]["tag"]=0
				else:
					for i in range(len(datasplit)):
						if(datasplit[i].split()[0]!="root"):
							result[u"数据库运行权限"][u"mongodb"]["describe"]=datasplit[i].split()[0]
							if(datasplit[i].split()[0]=="root"):
								result[u"数据库运行权限"]["mongodb"]["tag"]=1
							else:
								result[u"数据库运行权限"]["mongodb"]["tag"]=0
				result[u"数据库运行权限"]["mongodb"]["level"]=u"高危"
				result[u"数据库运行权限"]["mongodb"]["repair"]=u"禁止使用root权限启动mongodb"

			
			if(len(result[u"数据库运行权限"])==0):
				return {u"数据库运行权限":{"":{"describe":u"该服务器没有数据库","tag":0,"level":u"高危","repair":u"暂无"}},"rows":1}
			else:
				result["rows"]=len(result[u"数据库运行权限"])
			return result
		except Exception as e:
			return {u"数据库运行权限":{"":{"describe":u"数据库扫描错误，请手动检查","tag":1,"level":u"高危","repair":u"请重新检查服务器上的数据库运行权限是否为root"}},"rows":1}
			print (e)



a=databasePoc()
print (a.verify())

