#!/usr/bin/env python
#encoding=utf-8

# __author__ test
# __time__ 2018-5-4

import subprocess
import sys

		
class securityPolicyPoc(object):
	"""docstring for  portScanner"""
	vulID = '0'  # ssvid ID 如果是提交漏洞的同时提交 PoC,则写成 0
	version = '1' #默认为1
	vulDate = '2018-05-07' #漏洞公开的时间,不知道就写今天

	author = 'test' #  PoC作者的大名
	createDate = '2018-05-07'# 编写 PoC 的日期
	updateDate = '2018-05-07'# PoC 更新的时间,默认和编写时间一样
	references = []# 漏洞地址来源,0day不用写
	name = 'securityPolicyPoc'# PoC 名称
	appPowerLink = ''# 漏洞厂商主页地址
	appName = ''# 漏洞应用名称
	appVersion = ''# 漏洞影响版本
	vulType = ''#漏洞类型,类型参考见 漏洞类型规范表
	desc = '''
		查看系统安全策略设置
		1. 是否开启aslr：在一定程度上可以阻止溢出攻击  cat /proc/sys/kernel/randomize_va_space
		
	''' # 漏洞简要描述
	samples = []# 测试样列,就是用 PoC 测试成功的网站
	install_requires = [] # PoC 第三方模块依赖，请尽量不要使用第三方模块，必要时请参考《PoC第三方模块依赖说明》填写



	#验证漏洞
	def verify(self):
		
		try:
			aslrlPayload="cat /proc/sys/kernel/randomize_va_space"
			commandResult=float(subprocess.getoutput(aslrlPayload))
			
			#保存结果
			result={u"系统安全策略":{}}
			#是否开启aslr
			if(commandResult==2):
				result={u"系统安全策略":{"":{"describe":u"是否开启aslr:开启","tag":0,"level":u"高危","repair":u"服务器上开启aslr"}},"rows":1}
			elif(commandResult==1):
				result={u"系统安全策略":{"":{"describe":u"是否开启aslr:没有开启","tag":1,"level":u"高危","repair":u"服务器上开启aslr"}},"rows":1}
			return result
		except Exception as e:
			return {u"系统安全策略":{"":{"describe":u"系统安全策略扫描错误，请手动检查","tag":1,"level":u"高危","repair":u"请重新检查服务器上是否开启了aslr"}},"rows":1}
			



a=securityPolicyPoc()
print (a.verify())
