#!/usr/bin/env python
#encoding=utf-8

# __author__ test
# __time__ 2018-4-25

import subprocess
import sys
import re

		
class  PostgresqlPoc(object):
	"""docstring for  portScanner"""
	vulID = '0'  # ssvid ID 如果是提交漏洞的同时提交 PoC,则写成 0
	version = '1' #默认为1
	vulDate = '2018-05-16' #漏洞公开的时间,不知道就写今天

	author = 'fanyingjie' #  PoC作者的大名
	createDate = '2018-05-16'# 编写 PoC 的日期
	updateDate = '2018-05-16'# PoC 更新的时间,默认和编写时间一样
	references = []# 漏洞地址来源,0day不用写
	name = 'PostgresqlPoc'# PoC 名称
	appPowerLink = ''# 漏洞厂商主页地址
	appName = 'Postgresql'# 漏洞应用名称
	appVersion = ''# 漏洞影响版本
	vulType = ' Postgresql 未授权访问'#漏洞类型,类型参考见 漏洞类型规范表
	desc = '''
		1. Postgresql 运行时的权限 ps -ef |grep postgres|grep -v grep| awk '{print $1}'
		2. 允许访问的ip  vi /var/lib/pgsql/9.6/data/postgresql.conf
		3. 不需要密码：	vi /var/lib/pgsql/9.6/data/pg_hba.conf
	''' # 漏洞简要描述 
	samples = []# 测试样列,就是用 PoC 测试成功的网站
	install_requires = [] # PoC 第三方模块依赖，请尽量不要使用第三方模块，必要时请参考《PoC第三方模块依赖说明》填写



	#验证漏洞
	def verify(self):
		payload="ps -ef |grep postgres|grep -v grep|grep -v python| awk '{print $1}'"
		commandResult=subprocess.getoutput(payload)
		authority=list(set(commandResult.split("\n")))[0] #Postgresql运行时的权限
		result={"postgres":{}}
		if(commandResult==""):
			return {u"postgres":{"":{"describe":u"服务器未安装postgres","tag":0,"level":u"高危","repair":u"暂无"}},"rows":1}
		try:
			result["postgres"][u"运行权限"]={}
			result["postgres"][u"运行权限"]["describe"]=authority
			#对权限判断
			if(authority=="root"):
				result["postgres"][u"运行权限"]["tag"]=1
			else:
				result["postgres"][u"运行权限"]["tag"]=0
			result["postgres"][u"运行权限"]["level"]=u"严重"
			result["postgres"][u"运行权限"]["repair"]=u"禁止使用root权限启动postgres服务"
				
			payload="cat /var/lib/pgsql/9.6/data/postgresql.conf"

			ippattern="\\n\s{0,6}listen_addresses\s{0,6}=\s{0,6}'\*'" #是否允许任何人访问
			commandResult=subprocess.getoutput(payload)

			
			if("No such file" in commandResult):#没有读取到配置文件
				postgresqlConf_tmp=subprocess.getoutput('find / -name "postgresql.conf"').split("\n")
				postgresqlConf_tmp=list(set(postgresqlConf_tmp))
				postgresqlConf=[]
				configMD5={}
				for r in postgresqlConf_tmp:
					if("find:" not in r):
						configMD5[(subprocess.getoutput("md5sum %s"%r))[:32]]=r
						postgresqlConf.append(r)
				if(len(postgresqlConf)==0):	
					result["postgres"][u"配置文件位置"]={}
					result["postgres"][u"配置文件位置"]["describe"]=u"未找到"
					result["postgres"][u"配置文件位置"]["tag"]=1
					result["postgres"][u"配置文件位置"]["level"]=u"高危"
					result["postgres"][u"配置文件位置"]["repair"]=u"请手动检查配置文件postgresql.conf"
					result["rows"]=2
					return result
				for r in configMD5:
					payload="cat %s"%(configMD5[r])
					commandResult=subprocess.getoutput(payload)

					ipresult=re.findall(ippattern,commandResult)

					result["postgres"][u"访问控制%s"%(configMD5[r])]={}
			
					if(len(ipresult)!=0):
						result["postgres"][u"访问控制%s"%(configMD5[r])]["describe"]=u"允许任何人访问"
						result["postgres"][u"访问控制%s"%(configMD5[r])]["tag"]=1
					else:
						result["postgres"][u"访问控制%s"%(configMD5[r])]["describe"]=u"禁止任何人访问"
						result["postgres"][u"访问控制%s"%(configMD5[r])]["tag"]=0
					result["postgres"][u"访问控制%s"%(configMD5[r])]["level"]=u"严重"
					result["postgres"][u"访问控制%s"%(configMD5[r])]["repair"]=u"禁止允许任何人访问postgresql"



			payload="cat /var/lib/pgsql/9.6/data/pg_hba.conf"			
			commandResult=subprocess.getoutput(payload)
			if("No such file" in commandResult):#没有读取到配置文件
				postgresqlConf_tmp=subprocess.getoutput('find / -name "pg_hba.conf"').split("\n")
				postgresqlConf=[]
				configMD5={}
				for r in postgresqlConf_tmp:
					if("find:" not in r):
						configMD5[(subprocess.getoutput("md5sum %s"%r))[:32]]=r
						postgresqlConf.append(r)

				if(len(postgresqlConf)==0):	
					result["postgres"][u"配置文件位置%s"%(configMD5[r])]={}
					result["postgres"][u"配置文件位置%s"%(configMD5[r])]["describe"]=u"未找到"
					result["postgres"][u"配置文件位置%s"%(configMD5[r])]["tag"]=1
					result["postgres"][u"配置文件位置%s"%(configMD5[r])]["level"]=u"高危"
					result["postgres"][u"配置文件位置%s"%(configMD5[r])]["repair"]=u"请手动检查配置文件pg_hba.conf"
					result["rows"]=2
					return result
				for r in configMD5:
					payload="cat %s"%(configMD5[r])
					commandResult=subprocess.getoutput(payload)

					passpattern="\\n\s{0,6}host\s{0,20}all\s{0,20}all\s{0,20}0\.0\.0\.0/0\s{0,20}trust"
					passresult=re.findall(passpattern,commandResult)
			
					result["postgres"][u"密码控制%s"%(configMD5[r])]={}
					
					if(len(passresult)!=0):
						result["postgres"][u"密码控制%s"%(configMD5[r])]["describe"]=u"不需要密码"
						result["postgres"][u"密码控制%s"%(configMD5[r])]["tag"]=1
					else:
						result["postgres"][u"密码控制%s"%(configMD5[r])]["describe"]=u"需要密码"
						result["postgres"][u"密码控制%s"%(configMD5[r])]["tag"]=0
					result["postgres"][u"密码控制%s"%(configMD5[r])]["level"]=u"严重"
					result["postgres"][u"密码控制%s"%(configMD5[r])]["repair"]=u"postgresql禁止无密码访问，要设置密码控制"
					result["rows"]=3
			return result

		except Exception as e:
			print (e)
			return {u"postgres":{"":{"describe":u"postgres配置文件未找到,检查出错,请手工检查","tag":1,"level":u"高危","repair":u"请重新检查服务器上postgreqsql的配置文件：pg_hba.conf、postgresql.conf"}},"rows":1}	



a=PostgresqlPoc()
print (a.verify())
