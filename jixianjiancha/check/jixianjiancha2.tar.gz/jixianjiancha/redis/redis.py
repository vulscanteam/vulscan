#!/usr/bin/env python
#encoding=utf-8

# __author__ test
# __time__ 2018-4-25

import subprocess
import sys
import re


		
class  redisPoc(object):
	"""docstring for  portScanner"""
	vulID = '0'  # ssvid ID 如果是提交漏洞的同时提交 PoC,则写成 0
	version = '1' #默认为1
	vulDate = '2018-05-15' #漏洞公开的时间,不知道就写今天

	author = 'fanyingjie' #  PoC作者的大名
	createDate = '2018-05-15'# 编写 PoC 的日期
	updateDate = '2018-05-15'# PoC 更新的时间,默认和编写时间一样
	references = []# 漏洞地址来源,0day不用写
	name = 'redisPoc'# PoC 名称
	appPowerLink = ''# 漏洞厂商主页地址
	appName = 'redis'# 漏洞应用名称
	appVersion = ''# 漏洞影响版本
	vulType = ' redis 未授权访问'#漏洞类型,类型参考见 漏洞类型规范表
	desc = '''
		Redis 默认情况下,会绑定在 0.0.0.0:6379，这样将会将 Redis 服务暴露到公网上，
		如果在没有开启认证的情况下，可以导致任意用户在可以访问目标服务器的
		情况下未授权访问 Redis 以及读取 Redis 的数据。攻
		击者在未授权访问 Redis 的情况下可以利用 Redis 的相关方法,
		可以成功在 Redis 服务器上写入公钥，进而可以使用对应私钥直接登录目标服务器。

		1. redis 运行时的权限 ps -ef |grep redis|grep -v grep|grep -v python| awk '{print $1}'
		2. bind 0.0.0.0  任何人都可以登录
		3. requirepass foobared  设置了密码
	''' # 漏洞简要描述
	samples = []# 测试样列,就是用 PoC 测试成功的网站
	install_requires = [] # PoC 第三方模块依赖，请尽量不要使用第三方模块，必要时请参考《PoC第三方模块依赖说明》填写



	#验证漏洞
	def verify(self):
		payload="ps -ef |grep redis|grep -v grep|grep -v python| awk '{print $1}'"
		commandResult=subprocess.getoutput(payload)
		authority=commandResult.split("\n")  #redis运行时的权限
		result={u"redis":{}}
		if(commandResult==""):
			return {u"redis":{"":{"describe":u"服务器未安装redis","tag":0,"level":u"严重","repair":u"暂无"}},"rows":1}
		try:
			#redis运行时的权限是否是root
			result[u"redis"][u"运行权限"]={}
			result[u"redis"][u"运行权限"]["describe"]=authority[0]
			result[u"redis"][u"运行权限"]["tag"]=1
			result[u"redis"][u"运行权限"]["level"]=u"严重"
			result[u"redis"][u"运行权限"]["repair"]=u"禁止使用root权限启动redis服务"
			for a in authority:
				if(a!="root"):
					result[u"redis"][u"运行权限"]["describe"]=a
					result[u"redis"][u"运行权限"]["tag"]=0	



			
			payload="cat /etc/redis.conf"

			ippattern=r'\\n\s{0,6}bind\s{0,5}0\.0\.0\.0' #是否允许任何人访问
			passpattern=r'\\n\s{0,6}requirepass\s{0,5}.*?\\n'
			commandResult=subprocess.getoutput(payload)

			if("No such file" in commandResult):
				redisConf_tmp=subprocess.getoutput('find / -name "redis.conf"').split("\n")
				if(redisConf_tmp[0]==''):
					result[u"redis"][u"配置文件位置"]={}
					result[u"redis"][u"配置文件位置"]["describe"]=u"未找到"
					result[u"redis"][u"配置文件位置"]["tag"]=1
					result[u"redis"][u"配置文件位置"]["level"]=u"高危"
					result[u"redis"][u"配置文件位置"]["repair"]=u"请手工检查redis.conf配置文件"
					result["rows"]=2
					return result
				redisConf=[]
				configMD5={}
				for r in redisConf_tmp:
					if("find:" not in r):
						configMD5[subprocess.getoutput("md5sum r")]=r
						redisConf.append(r)
				

				set(configMD5)
				for r in configMD5:
					payload="cat %s"%(configMD5[r])
					commandResult=subprocess.getoutput(payload)
					ipresult=re.findall(ippattern,commandResult)
					result[u"redis"][u"访问控制%s"%(configMD5[r])]={}

					if(len(ipresult)!=0):
						ipresult=u"允许任何人访问"
						result[u"redis"][u"访问控制%s"%(configMD5[r])]["tag"]=1
					else:
						ipresult=u"对访问ip做了限制"
						result[u"redis"][u"访问控制%s"%(configMD5[r])]["tag"]=0
						result[u"redis"][u"访问控制%s"%(configMD5[r])]["describe"]=ipresult
						result[u"redis"][u"访问控制%s"%(configMD5[r])]["level"]=u"高危"
						result[u"redis"][u"访问控制%s"%(configMD5[r])]["repair"]=u"对redis访问ip做限制"


					passresult=re.findall(passpattern,commandResult)
					result[u"redis"][u"密码控制%s"%(configMD5[r])]={}
					if(len(passresult)!=0):
						passresult=u"设置了密码"
						result[u"redis"][u"密码控制%s"%(configMD5[r])]["tag"]=0
					else:
						passresult=u"未设置密码"
						result[u"redis"][u"密码控制%s"%(configMD5[r])]["tag"]=1
						result[u"redis"][u"密码控制%s"%(configMD5[r])]["describe"]=passresult
						result[u"redis"][u"密码控制%s"%(configMD5[r])]["level"]=u"严重"
						result[u"redis"][u"密码控制%s"%(configMD5[r])]["repair"]=u"对redis设置密码，禁止无密码访问"
						result["rows"]=3
				return result

		except Exception as e:
			return {u"redis":{"":{"describe":u"redis配置文件未找到,检查出错,请手工检查","tag":1,"level":u"高危","repair":u"请手工检查redis.conf配置文件(联系网络安全部)"}},"rows":1}



a=redisPoc()
print (a.verify())
