#!/usr/bin/env python
#encoding=utf-8

# __author__ test
# __time__ 2018-4-25

import subprocess
import sys
import re

		
class  Process(object):
	"""docstring for  portScanner"""
	vulID = '0'  # ssvid ID 如果是提交漏洞的同时提交 PoC,则写成 0
	version = '1' #默认为1
	vulDate = '2018-06-20' #漏洞公开的时间,不知道就写今天

	author = 'fanyingjie' #  PoC作者的大名
	createDate = '2018-06-20'# 编写 PoC 的日期
	updateDate = '2018-06-20'# PoC 更新的时间,默认和编写时间一样
	references = []# 漏洞地址来源,0day不用写
	name = 'process '# PoC 名称
	appPowerLink = ''# 漏洞厂商主页地址
	appName = 'process '# 漏洞应用名称
	appVersion = 'all version'# 漏洞影响版本
	vulType = 'information gather'#漏洞类型,类型参考见 漏洞类型规范表
	desc = '''
		将远程服务器上的进程保存到本地
	''' # 漏洞简要描述
	samples = []# 测试样列,就是用 PoC 测试成功的网站
	install_requires = [] # PoC 第三方模块依赖，请尽量不要使用第三方模块，必要时请参考《PoC第三方模块依赖说明》填写



	#验证漏洞
	def verify(self):
		payload="ps -aux"
		try:
			commandResult=subprocess.getoutput(payload)
			pattern="\d:\d\d"
			process_result=""
			for p1 in commandResult.split("\n"):
				process_list=re.split(pattern,p1)
				if(len(process_list)==2):
					process_result+=process_list[1]+"\n"	

			return {u"服务器进程读取":{"":{"describe":process_result,"tag":0,"level":u"高危","repair":u"暂无"}},"rows":1}
		except Exception as e:
			print (e)
			return {u"服务器进程读取":{"":{"describe":u"进程读取失败","tag":1,"level":u"高危","repair":u"请手工检查进程"}},"rows":1}
		



a=Process()
print (a.verify())
