#!/usr/bin/env python
#encoding=utf-8

# __author__ test
# __time__ 2018-4-25

import subprocess
import sys
import re
		
class  wgetPoc(object):
	"""docstring for  portScanner"""
	vulID = '0'  # ssvid ID 如果是提交漏洞的同时提交 PoC,则写成 0
	version = '1' #默认为1
	vulDate = '2018-04-27' #漏洞公开的时间,不知道就写今天

	author = 'test' #  PoC作者的大名
	createDate = '2018-04-27'# 编写 PoC 的日期
	updateDate = '2018-04-27'# PoC 更新的时间,默认和编写时间一样
	references = []# 漏洞地址来源,0day不用写
	name = 'wget 符号连接 重定向'# PoC 名称
	appPowerLink = ''# 漏洞厂商主页地址
	appName = 'wget'# 漏洞应用名称
	appVersion = '1.18之前'# 漏洞影响版本
	vulType = ' wget 符号连接 重定向'#漏洞类型,类型参考见 漏洞类型规范表
	desc = '''
		wget 作为*nix 系统常用下载工具，支持http、https、ftp 等多种协议，
		当使用wget 下载文件时，若初始下载http服务提供的下载资源， 如果服务器将下载资源重定向到ftp服务时，
		wget 会默认信赖http服务器重定向的ftp 链接地址和文件名，而不做二次验证。
		从而可能下载到恶意钓鱼者的恶意文件，导致主机被入侵。
	''' # 漏洞简要描述
	samples = []# 测试样列,就是用 PoC 测试成功的网站
	install_requires = [] # PoC 第三方模块依赖，请尽量不要使用第三方模块，必要时请参考《PoC第三方模块依赖说明》填写



	#验证漏洞
	def verify(self):
		payload="wget -V"
		tag=True
		try:
			commandResult=subprocess.getoutput(payload)
			pattern=r"GNU Wget (\d\.\d\d)"
			versionNumber=float(re.search(pattern,commandResult).groups(0)[0])
			if(versionNumber<1.16):
				tag=False
				return {u"wget漏洞":{"":{"describe":u"服务器存在wget符号链接、重定向漏洞","tag":1,"level":u"高危","repair":u"升级wget 版本号需大于1.18"}},"rows":1}
			if(versionNumber<1.18):
				tag=False
				return {u"wget漏洞":{"":{"describe":u"服务器存在wget重定向漏洞","tag":1,"level":u"高危","repair":u"升级wget 版本号需大于1.18"}},"rows":1}
			if(tag):
				return {u"wget漏洞":{"":{"describe":u"服务器不存在wget漏洞","tag":0,"level":u"高危","repair":u"升级wget 版本号需大于1.18"}},"rows":1}
		except Exception as e:
			return {u"wget漏洞":{"":{"describe":u"本服务器没有安装wget","tag":0,"level":u"高危","repair":u"升级wget 版本号需大于1.18"}},"rows":1}
		



a=wgetPoc()
print (a.verify())
