#!/usr/bin/env python
#encoding=utf-8

# __author__ test
# __time__ 2018-5-4

import subprocess
import sys




		
class  middlewarePoc(object):
	"""docstring for  portScanner"""
	vulID = '0'  # ssvid ID 如果是提交漏洞的同时提交 PoC,则写成 0
	version = '1' #默认为1
	vulDate = '2018-05-04' #漏洞公开的时间,不知道就写今天

	author = 'test' #  PoC作者的大名
	createDate = '2018-05-04'# 编写 PoC 的日期
	updateDate = '2018-05-04'# PoC 更新的时间,默认和编写时间一样
	references = []# 漏洞地址来源,0day不用写
	name = 'middlewarePoc'# PoC 名称
	appPowerLink = ''# 漏洞厂商主页地址
	appName = ''# 漏洞应用名称
	appVersion = ''# 漏洞影响版本
	vulType = ''#漏洞类型,类型参考见 漏洞类型规范表
	desc = '''
		查看中间件的当前允许用户
		1. apache httpd  ps -ef |grep httpd|grep -v grep|awk  '{print $1,$3}'
		2. nginx   ps -ef |grep nginx|grep "worker process"|awk '{print $1}'
		3. tomcat  ps -ef |grep tomcat |grep -v grep|awk '{print $1}'
	''' # 漏洞简要描述
	samples = []# 测试样列,就是用 PoC 测试成功的网站
	install_requires = [] # PoC 第三方模块依赖，请尽量不要使用第三方模块，必要时请参考《PoC第三方模块依赖说明》填写



	#验证漏洞
	def verify(self):
		
		try:
			apachePayload="ps -ef |grep httpd|grep -v grep|awk  '{print $1,$3}'"
			commandResult=subprocess.getoutput(apachePayload)
			datasplit=list(set(commandResult.split("\n")))
			
			#保存结果
			result={u"中间件运行权限":{}}
			
			#apache
			if(datasplit[0]!=""):
				result[u"中间件运行权限"]["apache"]={}
				if(len(datasplit)==1):
					result[u"中间件运行权限"]["apache"]["describe"]=datasplit[0].split()[0]
					if(datasplit[0].split()[0]=="root"):
						result[u"中间件运行权限"]["apache"]["tag"]=1
					else:
						result[u"中间件运行权限"]["apache"]["tag"]=0
				else:
					for i in range(len(datasplit)):
						if(datasplit[i].split()[1]!="1"):
							result[u"中间件运行权限"]["apache"]["describe"]=datasplit[i].split()[0]
							if(datasplit[i].split()[0]=="root"):
								result[u"中间件运行权限"]["apache"]["tag"]=1
							else:
								result[u"中间件运行权限"]["apache"]["tag"]=0
				result[u"中间件运行权限"]["apache"]["level"]=u"高危"
				result[u"中间件运行权限"]["apache"]["repair"]=u"禁止使用root权限启动apache服务"

			#nginx
			nginxPayload1="ps -ef |grep nginx|grep 'worker process'|grep -v grep|awk '{print $1}'"
			commandResult1=subprocess.getoutput(nginxPayload1)
			datasplit1=list(set(commandResult1.split("\n")))
			if(datasplit1[0]!="") :
				result[u"中间件运行权限"]["nginx"]={}
				if(len(datasplit1)==1):
					result[u"中间件运行权限"]["nginx"]["describe"]=datasplit1[0].split()[0]
					if(datasplit1[0].split()[0]=="root"):
						result[u"中间件运行权限"]["nginx"]["tag"]=1
					else:
						result[u"中间件运行权限"]["nginx"]["tag"]=0
				else:
					users=""
					result[u"中间件运行权限"]["nginx"]["tag"]=0
					for d in datasplit1:
						if(d.split()[0]=="root"):
							result[u"中间件运行权限"]["nginx"]["tag"]=1
						users+=d+"|"
					result[u"中间件运行权限"]["nginx"]["describe"]=users
				result[u"中间件运行权限"]["nginx"]["level"]=u"高危"
				result[u"中间件运行权限"]["nginx"]["repair"]=u"禁止使用root权限启动nginx服务"
				


			
			#tomcat
			tomcatPayload="ps -ef |grep tomcat|grep -v grep|awk '{print $1}'"
			commandResult=subprocess.getoutput(tomcatPayload)
			datasplit=list(set(commandResult.split("\n")))
			if(datasplit[0]!=""):
				result[u"中间件运行权限"]["tomcat"]={}
				if(len(datasplit)==1 ):
					result[u"中间件运行权限"][u"tomcat"]["describe"]=datasplit[0].split()[0]
					if(datasplit1[0].split()[0]=="root"):
						result[u"中间件运行权限"]["tomcat"]["tag"]=1
					else:
						result[u"中间件运行权限"]["tomcat"]["tag"]=0
				result[u"中间件运行权限"]["tomcat"]["level"]=u"高危"
				result[u"中间件运行权限"]["tomcat"]["repair"]=u"禁止使用root权限启动tomcat服务"

			result[u"rows"]=len(result[u"中间件运行权限"])
			if(len(result[u"中间件运行权限"])==0):
				return {u"中间件运行权限":{"":{"describe":u"该服务器没有中间件","tag":0,"level":u"高危","repair":u"暂无"}},"rows":1}
			return result
		except Exception as e:
			return {u"中间件运行权限":{"":{"describe":u"中间件扫描错误，请手动检查","tag":1,"level":u"高危","repair":u"请重新检查服务器是否存在root权限启动的中间件(请联系网络安全部)"}},"rows":1}
			print (e)



a=middlewarePoc()
print (a.verify())

